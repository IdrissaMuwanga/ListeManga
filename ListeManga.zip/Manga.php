<?php
require_once 'Modele/Modele.php';
class Manga extends Modele {
  // Renvoie la liste des mangas du blog
  public function getMangas() {
    $sql = 'select Manga_ID as id, Date_Parution as date,'
      . ' Manga_Titre as titre, Resume as contenu from Manga'
      . ' order by Manga_ID desc';
    $mangas = $this->executerRequete($sql);
    return $mangas;
  }
  // Renvoie les informations sur un manga
  public function getManga($idManga) {
    $sql = 'select Manga_ID as id, Date_Parution as date,'
      . ' Manga_Titre as titre, Resume as contenu from Manga'
      . ' where Manga_ID=?';
    $manga = $this->executerRequete($sql, array($idManga));
    if ($manga->rowCount() == 1)
      return $manga->fetch();  // Accès à la première ligne de résultat
    else
      throw new Exception("Aucun manga ne correspond à l'identifiant '$idManga'");
    }
}