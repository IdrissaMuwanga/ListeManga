<!doctype html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" href="Contenu/style.css" />
    <title><?= $titre ?></title>   <!-- Élément spécifique -->
    </head>
  <body>
    <div id="global">
      <header>
        <a href="index.php"><h1 id="titreListe">Liste Manga</h1></a>
        <p>Je vous souhaite la bienvenue sur cette liste de manga.</p>
      </header>
      <div id="contenu">
        <?= $contenu ?>   <!-- Élément spécifique -->
      </div>
      <footer id="piedListe">
        Blog réalisé avec PHP, HTML5 et CSS.
      </footer>
    </div> <!-- #global -->
  </body>
</html>