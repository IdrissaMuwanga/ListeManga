<?php
require 'Modele/Modele.php';
// Affiche la liste de tous les mangas de la liste
function accueil() {
  $mangas = getMangas();
  require 'Vue/vueAccueil.php';
}
// Affiche les détails sur un manga
function manga($idManga) {
  $manga = getManga($idManga);
  $mangakas = getMangakas($idManga);
  require 'Vue/vueManga.php';
}
// Affiche une erreur
function erreur($msgErreur) {
  require 'Vue/vueErreur.php';
}