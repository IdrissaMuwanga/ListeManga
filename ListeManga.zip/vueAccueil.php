<?php $this->titre = "ListeManga"; ?>
<?php foreach ($mangas as $manga):
    ?>
    <article>
        <header>
            <a href="<?= "index.php?action=manga&id=" . $manga['id'] ?>">
                <h1 class="titreManga"><?= $manga['titre'] ?></h1>
            </a>
        </header>      
    </article>
    <hr />
<?php endforeach; ?>