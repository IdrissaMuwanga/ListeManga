<?php
require_once 'Controleur/ControleurAccueil.php';
require_once 'Controleur/ControleurManga.php';
require_once 'Vue/Vue.php';
class Routeur {
  private $ctrlAccueil;
  private $ctrlManga;
  public function __construct() {
    $this->ctrlAccueil = new ControleurAccueil();
    $this->ctrlManga = new ControleurManga();
  }
  // Traite une requête entrante
  public function routerRequete() {
    try {
      if (isset($_GET['action'])) {
        if ($_GET['action'] == 'manga') {
          if (isset($_GET['id'])) {
            $idManga = intval($_GET['id']);
            if ($idManga != 0) {
              $this->ctrlManga->manga($idManga);
            }
            else
              throw new Exception("Identifiant de manga non valide");
          }
          else
            throw new Exception("Identifiant de manga non défini");
        }
        else
            throw new Exception("Action non valide");
      }
      else {  // aucune action définie : affichage de l'accueil
        $this->ctrlAccueil->accueil();
      }
    }
    catch (Exception $e) {
      $this->erreur($e->getMessage());
    }
  }
  // Affiche une erreur
  private function erreur($msgErreur) {
    $vue = new Vue("Erreur");
    $vue->generer(array('msgErreur' => $msgErreur));
  }
}