<?php
require_once 'Modele/Modele.php';
class Mangaka extends Modele {
  // Renvoie la liste des mangakas associés à un manga
  public function getMangakas($idManga) {
    $sql = 'select Mangaka_ID as id, Date_De_Naissance as date,'
      . ' Nom_Mangaka as auteur, Manga_Populaire as contenu from Mangaka'
      . ' where Mangaka_ID=?';
    $mangakas = $this->executerRequete($sql, array($idManga));
    return $mangakas;
  }
  // Ajoute un commentaire dans la base
   public function ajouterMangaka($auteur, $contenu, $idManga) {
    $sql = 'insert into Mangaka(Date_De_Naissance, Nom_Mangaka, Resume, Manga_ID)'
             . ' values(?, ?, ?, ?)';
    $date = date(DATE_W3C);  // Récupère la date courante
    $this->executerRequete($sql, array($date, $auteur, $contenu, $idManga));
  }
}

 