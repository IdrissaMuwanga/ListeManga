<?php
require_once 'Modele/Manga.php';
require_once 'Modele/Mangaka.php';
require_once 'Vue/Vue.php';
class ControleurManga {
  private $manga;
  private $mangaka;
  public function __construct() {
    $this->manga = new Manga();
    $this->mangaka = new Mangaka();
  }
  // Affiche les détails sur un manga
  public function manga($idManga) {
    $manga = $this->manga->getManga($idManga);
    $mangakas = $this->mangaka->getMangakas($idManga);
    $vue = new Vue("Manga");
    $vue->generer(array('manga' => $manga, 'mangakas' => $mangakas));
  }
  // Ajoute un commentaire à un manga
  public function commenter($auteur, $contenu, $idManga) {
    // Sauvegarde du mangaka
    $this->mangaka->ajouterMangaka($auteur, $contenu, $idManga); 
    // Actualisation de l'affichage du manga
    $this->manga($idManga);
  }
}