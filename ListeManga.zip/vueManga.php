<?php $titre = "Liste Manga - " . $manga['titre']; ?> 
<?php ob_start(); ?>
<article>
  <header>
    <h1 class="titreManga"><?= $manga['titre'] ?></h1>
    
    <time><p> Date de Parution: <?= $manga['date'] ?></time></p>
  </header>
  <p><?= $manga['contenu'] ?></p>
</article>
<hr />
<header>
  <h1 id="titreReponses">Parlez de <?= $manga['titre'] ?></h1>
</header>
<?php foreach ($mangakas as $mangaka): ?>

<?php endforeach; ?>
  <form method="post" action="index.php?action=commenter">
    <input id="auteur" name="auteur" type="text" placeholder="Votre pseudo" 
           required /><br />
    <textarea id="txtMangaka" name="contenu" rows="4" 
              placeholder="Votre commentaire" required></textarea><br />
    <input type="hidden" name="id" value="<?= $manga['id'] ?>" />
    <input type="submit" value="Commenter" />
</form>
<?php $contenu = ob_get_clean(); ?>
<?php require 'Gabarit.php'; ?>


