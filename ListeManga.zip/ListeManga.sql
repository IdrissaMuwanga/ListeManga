/* Testé sous MySQL 5.x */

drop table if exists Manga;
drop table if exists Mangaka;

--Creation Table Manga
create table Manga (
  Manga_ID integer primary key auto_increment,
  Manga_Titre varchar(100),
  Date_Parution varchar(100) not null,
  Nombre_Tomes integer not null,
  Resume varchar(400) not null,
  Nom_Mangaka varchar(100) not null,

) ENGINE=INNODB CHARACTER SET utf8 COLLATE utf8_general_ci;

--Creation Table Mangaka
create table Mangaka (
  Mangaka_ID integer primary key auto_increment,
  Nom_Mangaka varchar(100),
  Date_De_Naissance varchar(100) not null,
  Manga_Populaire varchar(100) not null,

) ENGINE=INNODB CHARACTER SET utf8 COLLATE utf8_general_ci;

--insertion valeurs dans la table manga
insert into Manga(Manga_Titre,Date_Parution,Nombre_Tomes,Resume,Nom_Mangaka) values
('Naruto','21 septembre 1999',72,'Naruto est un jeune ninja qui rêve de devenir le Hokage de son village.','Masashi Kishimoto');
insert into Manga(Manga_Titre,Date_Parution,Nombre_Tomes,Resume,Nom_Mangaka) values
('One Piece','22 juillet 1997',100,'Monkey.D.Luffy cherche le trésor, le one piece, le trésor du plus grand pirate de tous les temps, Gold Roger','Eiichiro Oda');
insert into Manga(Manga_Titre,Date_Parution,Nombre_Tomes,Resume,Nom_Mangaka) values
('Bleach','7 août 2001',74,'Ichigo Kurosaki un lycéen fait la rencontre d un shinigami qui va boulverser sa vie','Tite Kubo');
insert into Manga(Manga_Titre,Date_Parution,Nombre_Tomes,Resume,Nom_Mangaka) values
('Dragon Ball','20 novembre 1984',42,'Son Goku recherche les 7 dragons balls qui permettent de réaliser n importe quelle voeu','Akira Toriyama');
insert into Manga(Manga_Titre,Date_Parution,Nombre_Tomes,Resume,Nom_Mangaka) values
('Shingeki No Kyojin','9 septembre 2009',34,'Eren Jaëger, dont la vie a été ruiné par les titans, souhaitent s en venger en les exterminant tous','Hajime Isayama');
--insertion valeurs dans la table mangaka
insert into Mangaka(Nom_Mangaka,Date_De_Naissance,Manga_Populaire) values
('Masashi Kishimoto','8 novembre 1974','Naruto');
insert into Mangaka(Nom_Mangaka,Date_De_Naissance,Manga_Populaire) values
('Eiichiro Oda','1 Janvier','One Piece');
insert into Mangaka(Nom_Mangaka,Date_De_Naissance,Manga_Populaire) values
('Tite Kubo','26 juin 1977','Bleach');
insert into Mangaka(Nom_Mangaka,Date_De_Naissance,Manga_Populaire) values
('Akira Toriyama','5 avril 1955','Dragon Ball');
insert into Mangaka(Nom_Mangaka,Date_De_Naissance,Manga_Populaire) values
('Shingeki No Kyojin','29 août 1986','Shingeki No Kyojin');
